</head>

<body>

  <header class="page-header" id="navbar-fixed">
    <!-- topline -->
    <div class="page-header__topline" style="background-color:red">

      <div class="container clearfix" >
        
       
        <div class="currency">

          <a class="currency__change" style="color:white" href="my_account.php?my_orders">

          <?php
          if(!isset($_SESSION['customer_email'])){
          echo '<a href="../index.php" class="login__link" style="color:white">Madoxh</a>'; 

          }

          else
          { 
              
              
              echo '<b style="color:yellow">madoxhian </b>';
              echo $_SESSION['customer_email'] ; 
            }
?>
          </a>

        </div>
        
        <div class="basket">
          <a href="../cart.php" class="btn btn--basket" style="background-color:red;">
            <i class="icon-basket" style="color:yellow;"></i>
            <?php items(); ?> <b style="color:white">items</b>
          </a>
        </div>
        
        
        <ul class="login">



<li class="login__item">
<?php
if(!isset($_SESSION['customer_email'])){
  echo '<a href="../customer_register.php" class="login__link" style="color:white">Register</a>';
} 
  else
  { 
      echo '<a href="my_account.php?my_orders" style="color:white" class="login__link">My Account</a>';
  }   
?>  
</li>


<li class="login__item">
<?php
if(!isset($_SESSION['customer_email'])){
  echo '<a href="../checkout.php" class="login__link" style="color:white">Sign In</a>';
} 
  else
  { 
      echo '<a href="../logout.php" class="login__link" style="color:yellow">Log out</a>';
  }   
?>  
  
</li>
</ul>
      
      </div>
    </div>
    <!-- bottomline -->
    <link rel="stylesheet" href="../pan.css">
    <div class="page-header__bottomline" style="background-color: white">
      <div class="container clearfix">


        <!--search script-->

         <script type="text/javascript">
           $(document).ready(function(){
              $("#search-box").keyup(function(){
                $.ajax({
                type: "POST",
                url: "search.php",
                data:'keyword='+$(this).val(),
                beforeSend: function(){
                  $("#search-box").css("background","#FFF url(LoaderIcon.gif) no-repeat 165px");
                },
                success: function(data){
                  $("#suggesstion-box").show();
                  $("#suggesstion-box").html(data);
                  $("#search-box").css("background","#FFF");
                }
                });
              });
            });
            //To select country name
            function select(val) {
            $("#search-box").val(val);
            $("#suggesstion-box").hide();
            }
         </script>
 
      <center>
        <div class="logo">
          <a class="logo__link" href="../index.php">
            <img class="logo__img" src="images/ma.png"  width="237" height="19">
          </a>

        </div>

        
            <marquee style="width: 100%; background-color: orange"><b style="color:blue"> <?php if(isset($_SESSION['customer_email'])){echo $_SESSION['customer_email']; }else{
              echo "<b style='color: red'>login to place your orders</b>";
            }?> Madoxh most finest and high quality products now available at our stores worldwide , just make an order and we deliver the products at your doorstep </b></marquee> 
        <nav class="main-nav" >
              
              <div class="dropdown dropdown--lookbook">
                <div class="clearfix">
                  <div class="dropdown__half">
                    <div class="dropdown__heading">Account Settings</div>
                    <ul class="dropdown__items">
                      <li class="dropdown__item">
                        <a href="#" class="dropdown__link">My Wishlist</a>
                      </li>
                      <li class="dropdown__item">
                        <a href="#" class="dropdown__link">My Orders</a>
                      </li>
                      <li class="dropdown__item">
                        <a href="#" class="dropdown__link">View Shopping Cart</a>
                      </li>
                    </ul>
                  </div>
                  <div class="dropdown__half">
                    <div class="dropdown__heading"></div>
                    <ul class="dropdown__items">
                      <li class="dropdown__item">
                        <a href="customer/edit_account.php" class="dropdown__link">Edit Your Account</a>
                      </li>
                      <li class="dropdown__item">
                        <a href="customer/change_pass.php" class="dropdown__link">Change Password</a>
                      </li>
                      <li class="dropdown__item">
                        <a href="customer/delete_account.php" class="dropdown__link">Delete Account</a>
                      </li>
                    </ul>
                  </div>
                </div>
             

              </div>

            </li>

          </ul>
        </nav>
      </div>
    </div>
  </header>