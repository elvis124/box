<?php

include("includes/db.php");
include("includes/header.php");
?>

<div class="box"><!-- box Starts -->

<?php

$session_email = $_SESSION['customer_email'];

$select_customer = "select * from customers where customer_email='$session_email'";

$run_customer = mysqli_query($con,$select_customer);

$row_customer = mysqli_fetch_array($run_customer);

$customer_id = $row_customer['customer_id'];
$delivery_add = $row_customer['customer_address'];
$phone = $row_customer['customer_contact'];


$i = 0;

?>

<div id="content" ><!-- content Starts -->
<div class="container" ><!-- container Starts -->



<div class="col-md-9" id="cart" ><!-- col-md-9 Starts -->

<div class="box" ><!-- box Starts -->

<form action="cart.php" method="post" enctype="multipart-form-data" ><!-- form Starts -->

<h1 style="background-color: red; color: white"><center>payment </center> </h1>

<?php

$ip_add = getRealUserIp();

$select_cart = "select * from cart where ip_add='$ip_add'";

$run_cart = mysqli_query($con,$select_cart);

$count = mysqli_num_rows($run_cart);

?>



<div class="table-responsive" ><!-- table-responsive Starts -->

<table class="table"  style="background-color: orange"><!-- table Starts -->

<thead><!-- thead Starts -->

<tr>

<th colspan="2" >Product</th>

<th>Quantity</th>

<th>Unit Price</th>


<th colspan="2"> Sub Total </th>


</tr>

</thead><!-- thead Ends -->

<tbody><!-- tbody Starts -->

<?php

$total = 0;

while($row_cart = mysqli_fetch_array($run_cart)){

$pro_id = $row_cart['p_id'];

$pro_size = $row_cart['size'];

$pro_qty = $row_cart['qty'];

$only_price = $row_cart['p_price'];

$get_products = "select * from products where product_id='$pro_id'";

$run_products = mysqli_query($con,$get_products);

while($row_products = mysqli_fetch_array($run_products)){

$product_title = $row_products['product_title'];

$product_img1 = $row_products['product_img1'];

$shipping_fee = 150;

$sub_total = $only_price*$pro_qty;

$_SESSION['pro_qty'] = $pro_qty;

$total += $sub_total;

?>

<tr><!-- tr Starts -->

<td>

<img src="admin_area/product_images/<?php echo $product_img1; ?>" >

</td>

<td>

<a href="#" > <?php echo $product_title; ?> </a>

</td>

<td>

	<?php echo $pro_qty; ?>
	
</td>

<td>

$<?php echo $only_price; ?>.00

</td>

<td>

$<?php echo $sub_total; ?>.00

</td>

</tr><!-- tr Ends -->

<?php } } ?>

</tbody><!-- tbody Ends -->

<tfoot><!-- tfoot Starts -->

<tr>

<th colspan="5">phone</th>

<th colspan="2"><b style="color: white"> <?php echo $phone; ?></b> </th>

</tr>

<tr>

<th colspan="5">email </th>

<th colspan="2"><b style="color: white"> <?php echo $session_email; ?></b> </th>

</tr>

<tr>

<th colspan="5"> delivery address </th>

<th colspan="2"> <b style="color: white"><?php echo $delivery_add; ?></b> </th>

</tr>

<tr>

<th colspan="5"> shipping fee </th>

<th colspan="2"> sh<?php echo $shipping_fee; ?>.00 </th>

</tr>

<tr>

<th colspan="5"> Total </th>

<?php $all_mon = $shipping_fee + $total ?>

<th colspan="2"> sh<?php echo $all_mon; ?>.00 </th>

</tr>


</tfoot><!-- tfoot Ends -->

</table><!-- table Ends -->

<center>
<p style="width: 100%">
<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="encrypted" value="-----BEGIN PKCS7-----MIIISQYJKoZIhvcNAQcEoIIIOjCCCDYCAQExggEwMIIBLAIBADCBlDCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb20CAQAwDQYJKoZIhvcNAQEBBQAEgYBjk1X92DOAzowIEeZ9QC/E678MmpRUp1v2KtiCKWnEiEeuUDKs8O2LJUgDXn3m6BfC0okUtWTgpx+Kxzdc7r7Ed9S3i/Rc9JaXpLIcTjytIPOKECQrmEcRbrJXNRDhag8jzcBCs6v/UeOKJAsjTXlAVyIeqUyQtdNhmC6FCiiK4jELMAkGBSsOAwIaBQAwggHFBgkqhkiG9w0BBwEwFAYIKoZIhvcNAwcECGRU1DRCBIe7gIIBoL8CkpMFpUIeNX1IFXzPE/zAH9znt4YYDt/c+t0l+KIcHOo3fj2HvkjAwL65b64CKQ9K9e8skaLlK3X4TqgfNQTBmqrc1UpgiQ5qYTQvV1zJ/SD0/mkLLOOUrryNAldLtu7bpyWXxk7Zw3QZwXFetpH97MXCBuGh0SIh/0cZ/W6E5yuVLkqQQAqcXxKEMYUfZg/ZVowrqM0IzK1yZfGIzy0pftTG4cO4AEIKNyVrn9nGMnbmbQP1CxzTxat810LnEEdcvq3Gz9k2M1VNc1HRq2Vo1PAN199KIzQmiQxJ/8JZ+2wZMKgqsV9jMI/pQbIP7mn3S1b1XDC8f5JRSarEMJfBroIkNUidk0aSVq3lNJBnCHYcuXPALwOOX5Njpto78QOgTj9xsOop6vMVwev+VS7oqS4gw1hw2tAJ+IoX+6/5QRLV8CXiGj/jwB5KJ5ZNFo++W+PX8aVhrDc+rnV97TxjwcccZcDhuFMvZbn0DEaemC6oyzCuW6/oiT1pWt1VYw4JeUQkeKisZNyS0IL4ASvuyKNGZyaK9lYN4XH91sa6oIIDhzCCA4MwggLsoAMCAQICAQAwDQYJKoZIhvcNAQEFBQAwgY4xCzAJBgNVBAYTAlVTMQswCQYDVQQIEwJDQTEWMBQGA1UEBxMNTW91bnRhaW4gVmlldzEUMBIGA1UEChMLUGF5UGFsIEluYy4xEzARBgNVBAsUCmxpdmVfY2VydHMxETAPBgNVBAMUCGxpdmVfYXBpMRwwGgYJKoZIhvcNAQkBFg1yZUBwYXlwYWwuY29tMB4XDTA0MDIxMzEwMTMxNVoXDTM1MDIxMzEwMTMxNVowgY4xCzAJBgNVBAYTAlVTMQswCQYDVQQIEwJDQTEWMBQGA1UEBxMNTW91bnRhaW4gVmlldzEUMBIGA1UEChMLUGF5UGFsIEluYy4xEzARBgNVBAsUCmxpdmVfY2VydHMxETAPBgNVBAMUCGxpdmVfYXBpMRwwGgYJKoZIhvcNAQkBFg1yZUBwYXlwYWwuY29tMIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDBR07d/ETMS1ycjtkpkvjXZe9k+6CieLuLsPumsJ7QC1odNz3sJiCbs2wC0nLE0uLGaEtXynIgRqIddYCHx88pb5HTXv4SZeuv0Rqq4+axW9PLAAATU8w04qqjaSXgbGLP3NmohqM6bV9kZZwZLR/klDaQGo1u9uDb9lr4Yn+rBQIDAQABo4HuMIHrMB0GA1UdDgQWBBSWn3y7xm8XvVk/UtcKG+wQ1mSUazCBuwYDVR0jBIGzMIGwgBSWn3y7xm8XvVk/UtcKG+wQ1mSUa6GBlKSBkTCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb22CAQAwDAYDVR0TBAUwAwEB/zANBgkqhkiG9w0BAQUFAAOBgQCBXzpWmoBa5e9fo6ujionW1hUhPkOBakTr3YCDjbYfvJEiv/2P+IobhOGJr85+XHhN0v4gUkEDI8r2/rNk1m0GA8HKddvTjyGw/XqXa+LSTlDYkqI8OwR8GEYj4efEtcRpRYBxV8KxAW93YDWzFGvruKnnLbDAF6VR5w/cCMn5hzGCAZowggGWAgEBMIGUMIGOMQswCQYDVQQGEwJVUzELMAkGA1UECBMCQ0ExFjAUBgNVBAcTDU1vdW50YWluIFZpZXcxFDASBgNVBAoTC1BheVBhbCBJbmMuMRMwEQYDVQQLFApsaXZlX2NlcnRzMREwDwYDVQQDFAhsaXZlX2FwaTEcMBoGCSqGSIb3DQEJARYNcmVAcGF5cGFsLmNvbQIBADAJBgUrDgMCGgUAoF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMjEwNTE4MTkyOTM3WjAjBgkqhkiG9w0BCQQxFgQUpLOt3D/4QVAAaHAzUZLtWxS5WW8wDQYJKoZIhvcNAQEBBQAEgYBwDGf2lTWjjF4/5VVGyECCpWya35j+/Xy6we9vAePOj8c7b426SuthT/6QtezTfKYxGQRVejtKBKo7NmfN6m6t1QgoOmXj937AGJ0KLk2qpLaF6hf8CVsilwO8UYGLCKtS0O7Zspxz8LU2Abb3ZWf/8N/CCO2LBCoKeHTVYFKjjA==-----END PKCS7-----">
<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_buynowCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form>
</p>
</center>




<?php  ?>






</center><!-- center Ends -->

</div><!-- box Ends -->

 <center><h2><p ><a href="shop.php" style="background-color: red; color:white">Go back shopping</a></p></h2></center>
