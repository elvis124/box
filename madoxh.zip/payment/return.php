<html>
<head>
<title>Order Placed</title>
<style>
.response-text {
    display: inline-block;
    max-width: 550px;
    margin: 0 auto;
    font-size: 1.5em;
    text-align: center;
    background: #fff3de;
    padding: 42px;
    border-radius: 3px;
    border: #f5e9d4 1px solid;
    font-family: arial;
    line-height: 34px;
}
</style>
</head>
<body>
    <div class="response-text">

        <?php echo "script(alert('you have placed your orders successfully'));" ?>

    </div>
</body>
</html>