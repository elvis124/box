<footer class="page-footer">

	<div class="footer-nav">
		<div class="container clearfix">

			<div class="footer-nav__col footer-nav__col--info">
				<div class="footer-nav__heading">Information</div>
				<ul class="footer-nav__list">
					<li class="footer-nav__item">
						<a href="#" class="footer-nav__link">The brand</a>
					</li>
					<li class="footer-nav__item">
						<a href="#" class="footer-nav__link">Local stores</a>
					</li>
					<li class="footer-nav__item">
						<a href="#" class="footer-nav__link">Customer service</a>
					</li>
					<li class="footer-nav__item">
						<a href="#" class="footer-nav__link">Privacy &amp; cookies</a>
					</li>
					<li class="footer-nav__item">
						<a href="#" class="footer-nav__link">Site map</a>
					</li>
				</ul>
			</div>

			<div class="footer-nav__col footer-nav__col--whybuy">
				<div class="footer-nav__heading">Why buy from us</div>
				<ul class="footer-nav__list">
					<li class="footer-nav__item">
						<a href="#" class="footer-nav__link">Shipping &amp; returns</a>
					</li>
					<li class="footer-nav__item">
						<a href="#" class="footer-nav__link">Secure shipping</a>
					</li>
					<li class="footer-nav__item">
						<a href="#" class="footer-nav__link">Testimonials</a>
					</li>
					<li class="footer-nav__item">
						<a href="#" class="footer-nav__link">Always giving you the best quality</a>
					</li>
					<li class="footer-nav__item">
						<a href="#" class="footer-nav__link">Ethical trading</a>
					</li>
				</ul>
			</div>

			<div class="footer-nav__col footer-nav__col--account">
				<div class="footer-nav__heading">Your account</div>
				<ul class="footer-nav__list">
					<li class="footer-nav__item">
						<a href="customer/customer_login.php" class="footer-nav__link">Sign in</a>
					</li>
					<li class="footer-nav__item">
						<a href="customer_register.php" class="footer-nav__link">Register</a>
					</li>
					<li class="footer-nav__item">
						<a href="cart.php" class="footer-nav__link">View cart</a>
					</li>
					<li class="footer-nav__item">
						<a href="#" class="footer-nav__link">View your lookbook</a>
					</li>
					<li class="footer-nav__item">
						<a href="#" class="footer-nav__link">Track an order</a>
					</li>
					<li class="footer-nav__item">
						<a href="#" class="footer-nav__link">Update information</a>
					</li>
				</ul>
			</div>


			<div class="footer-nav__col footer-nav__col--contacts">
				<div class="footer-nav__heading">Contact details</div>
				<p><a href="contact.php">Contact us</a></p>
				<address class="address">
				Head Office: Kisumu,Riat.<br>
			    40105 Airport, kisumu.
			</address>
				<div class="phone">
					Telephone:
					<a class="phone__number" href="tel:0123456789">+254703180147</a>
				</div>
				<div class="email">
					Email:
					<a href="mailto:support@yourwebsite.com" class="email__addr">elvisianomondi@gmail.com</a>
				</div>
			</div>

		</div>
	</div>

	<div class="banners">
		<div class="container clearfix">

			<div class="banner-award">
				<span id="blin"><b style="color: white">MADOXH</b> <b style="color:green">MOST  FINEST</b><b style="color: yellow"> AND </b> <b style="color:red">UNIQUE</b> </span><br> 

			    <script type="text/javascript" >
	                var blink = document.getElementById('blin');
	                setInterval(function() {
	                blink.style.opacity = (blink.style.opacity == 0 ? 1 : 0);
	                }, 2000);
	            </script>
			</div>

			<div class="banner-social" style='background-color: red'>
				<a href="#" class="banner-social__link">
				<i class="icon-facebook"></i>
			</a>
				<a href="#" class="banner-social__link">
				<i class="icon-twitter"></i>
			</a>
				<a href="#" class="banner-social__link">
				<i class="icon-instagram"></i>
			</a>
				<a href="#" class="banner-social__link">
				<i class="icon-pinterest-circled"></i>
			</a>
			</div>

		</div>
	</div>

	<div class="page-footer__subline" style="background-color: red">
		<div class="container clearfix">

			<div class="copyright" style="color:white">
				&copy; Madoxh&trade;
			</div>

			<div class="developer" style="color:white">
				Dev Madoxh
			</div>

			<div class="designby" style="color:white">
				Design by Madoxh
			</div>
		</div>
	</div>
</footer>
