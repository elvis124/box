<?php 

include('../function/database.php');

if(isset($_POST['submit'])){
$code = $_POST['code'];
$c_code = md5($code);

$email = $_POST['email'];
$c_email = md5($email);

$password = $_POST['password'];
$c_password = md5($password);

$select = "select username from mx_users where secret_code=$c_code and email=$c_email and password=$c_password ";

$connect= mysqli_query($con, $select);
$check = mysqli_num_rows($connect);

if($check>0){
	$_SESSION['email'] = $email;

	echo "<script>alert('You have been Registered Successfully welcome to mx box')</script>";

	echo "<script>window.open('home/home.php','_self')</script>";

}else{
 
	echo "<script>alert('Your registartion is not Successful register and try again')</script>";

	echo "<script>window.open('../index.php','_self')</script>";
	
}

	
}


?>