<?php
include('../../function/database.php');

include('../home/header.php');

  $get_ip = getRealUserIp();

  $select = "select username from mb where ip_add='$get_ip'";

  $run_cart = mysqli_query($con,$select);

 /* if (mysqli_num_rows($run_cart)){
    while($row = mysqli_fecth_assoc($run_cart)){

        $username = $row['username'];

        $username = $_SESSION['username'];

    }

  }/*else{
    echo "<script>alert('please login to access this page if you dont have an account login')</script>";
    echo "<script>window.open('../../index.php', '_self')</script>";
  } */




?>





<div class="box6" id="page_details" style="justify-content: center; padding: 30px;" >
  <section id="main-content">
    <div id="guts" >
       <form action="#" method="POST" class="sign-up-form" enctype="multipart/form-data">
            
            <div class="form-group">
              <i class="fas fa-text"></i>
              <input type="text" name="title"  style="outline: none; width:100%; height: 2rem; padding: 20px;" placeholder="Title" required />
            </div>
            <div class="form-group">
              <textarea name="description"  placeholder="description" style="outline: none; width:100%; height: 6rem; padding: 20px;"></textarea>
            </div>
            <div class="form-group">
             <input type="file" name="image"  placeholder=" documents" style="outline: none; width:100%;  padding: 20px;" required />
            </div>

          
          <div class="form-group">
            <input type="submit" name="submit"  style="outline: none; width:100%; background-color: green;  padding: 20px;" class="btn" value="submit" />
          </div>
        </form>
         <h1><a href="../home/photos.php" style="outline: none; width:100%; padding: 20px;">back to home</a></h1>

    </div>
    </section>

</div>

<?php
   if(isset($_POST['submit'])){

    $title=$_POST['title'];
    $description = $_POST['description'];

      $create = "CREATE TABLE IF NOT EXISTS photo_files (
        
        photo_id INT AUTO_INCREMENT PRIMARY KEY,

        title VARCHAR(255) NOT NULL,

        email VARCHAR(255) NOT NULL,

        description VARCHAR(200) NOT NULL,

        image  NOT NULL,

        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )  ENGINE=INNODB";

        mysqli_query($conn, $create);

        // the physical file on a temporary uploads directory on the server
    $image = $_FILES['image']['name'];

    $c_image_tmp = $_FILES['image']['tmp_name'];

    $user_ip = getRealUserIp();

    move_uploaded_file($c_image_tmp,"../../images/user_images/$image");

    $sql = "INSERT INTO photo_files (email, title, description, image) VALUES ($email, '$title', $description, $image)";
    if (mysqli_query($conn, $sql)) {
      echo "File uploaded successfully";
          
      } else {
        echo "Failed to upload file.";
        }
      
  }

    







?>

</div>

<script>
  $(document).ready(function(){
      $(window).resize();
  });
  $(window).resize(function{
      // your code
      var windowWidth=$(window).width();
      var mainContainerWidth=windowWidth-100; // For example
      $("#yourMainContainer").css({"width":mainContainerWidth+"px"});
  });
</script>
    <script type='text/javascript' src='http://ajax.googleapis.com/ajax/libs/jquery/1.4/jquery.min.js'></script>

</body>
</html>