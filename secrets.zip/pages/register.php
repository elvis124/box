<?php 

include('../function/database.php');

//define  namespace

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

//create instance

$mail = new PHPMailer();
$mail -> isSMTP();
$mail -> HOST = "smtp.gmail.com";
$mail ->SMTPAuth= "true";
$mail -> Port = "587";


//connecting with the form

if(isset($_POST['register'])){

    $username = $_POST['username'];

    $c_user = md5($username);

    $number = $_POST['number'];

    $c_number = md5($number);

    $full_names = $_POST['full_names'];
    
    $c_full_names = md5($full_names);

    $email = $_POST['email'];

	$get_email = "SELECT * FROM mx_users WHERE email=$email";

	$re = mysqli_query($con, $get_email);

	$check_email = mysqli_fetch_array($re);

	if($check_email>0){

	echo "<script>alert('This email is already registered, try another one')</script>";

	exit();

    }

    $password = $_POST['password'];
    $c_password = md5($password);
	$c_image = $_FILES['image']['name'];
    $image = $_FILES['image']['tmp_name'];
    $user_ip = getRealUserIp();
    move_uploaded_file($image, "../images/user_images/$c_image");

//email connection
    $secret_code = getNumber(5);
    $c_code = md5($secret_code);

    
    $confirm_code = mt_rand();

    $mail -> Username = "MX box";
    $mail -> Password = "Goodper12son;;";
    $mail -> subject = "Email Confirmation Message";

    $mail -> sentfrom = "elvisianomondi@gmail.com";

    $mail -> isHTML(true);
    $mail -> addAttachment("../images/mx.png");

    $mail ->Body ="

    <h2>
    Email Confirmation By www.mxbox.com {$full_names}

    you have registered succefull your secret code is {$secret_code}, please keep it secret from any person beacause you will always use it to login always
    </h2>
    click here to login

    <a href='localhost/secret/pages/home/home.php?{$confirm_code}'>

    Click Here To Confirm Email

    </a>

    ";

    $mail -> addAddress("{$email}");

    if($mail ->Send()) {

        echo "Registration details has been send to you";

    } else {
        echo "please provide valid details";

    }

    $mail -> smtpClose();


	$insert_user= "INSERT INTO mx_users (user_ip,username,secret_code,phone_number,full_names,email,image,password) VALUES ('$user_ip','$c_user','$secret_code', '$c_number','$c_full_names', '$email', '$c_image','$c_password')";

	$result = mysqli_query($con, $insert_user);

	$_SESSION['email'] = $email;
    
	echo "<script>alert('You have been Registered Successfully')</script>";

    echo "<script>window.open('home/home.php','_self')</script>";
}

?>