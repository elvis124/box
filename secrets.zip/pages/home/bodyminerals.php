<div class="box3" id="page_details" >
	<section id="main-content">
	<div class="box" style="padding-left: 4rem; padding-top: 2rem">

	
    </div>
		<div id="guts">

    
            <p id="map">

                <h1>reach us at our main office for storage</h1>
            </p>

            <p>
              
              <div style="width: 100%"><iframe width="100%" height="600" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=100%25&amp;height=600&amp;hl=en&amp;q=kisumu%20airport,%20riat+(Mx%20box)&amp;t=&amp;z=14&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe><a href="https://www.maps.ie/draw-radius-circle-map/">Circle area map</a>
              </div>
            </p>

        </div>
    </section>
<script>
                 
  function initMap() {
      map = new google.maps.Map(document.getElementById('map'), {
      center: { lat: 41.763031, lng: -73.044465 },
      zoom: 17.75
      });

      google.maps.event.addListener(map, 'click', function (event) {
      new google.maps.Marker({
        position: event.latLng,
        map: map,
      });
      });
  }
</script>
</div>   