<div class="box4">
	<ul style="list-style-type: none; justify-content: center;">
		<li><img src="../../images/cap12.png" style="width: 100%;"></li>
		<li><img src="../../images/cap.jpg" style="width: 100%;"></li>
		<li><img src="../../images/cap12.png" style="width: 100%;"></li>
		<li><img src="../../images/water.gif" style="width: 100%;"></li>
	</ul>
		
</div>