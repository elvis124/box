<div class="box3" id="page_details" >
	<section id="main-content">
	<div class="box" style="padding-left: 4rem; padding-top: 2rem">
   <a href="../fileuploader/documentadd.php" style="background-color: transparent; color: yellowgreen; justify-content: center; width: 100%; outline: none"><b style="padding-left: 30px;">+ Add files</b></a>
	
    </div>

    
		<div id="guts">


        <div id="content" class="container"><!-- container Starts -->

          <div class="row" ><!-- row Starts -->
          <iframe width="853" height="480" src="https://www.youtube.com/embed/dkerRz1adDU" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

          </div><!-- row Ends -->

          </div><!-- container Ends -->
        </div>
    </section>

</div>   