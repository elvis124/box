<div class="box3" id="page_details" >
	<section id="main-content">
    <div class="box" style="padding-left: 4rem; padding-top: 2rem">
   <a href="../fileuploader/photoadd.php" style="background-color: transparent; color: yellowgreen; justify-content: center; width: 100%; outline: none">+ Add files</a>
  
</div>
		<div id="guts">


      <div id="content" class="container"><!-- container Starts -->

        <div class="row" ><!-- row Starts -->

        <?php

        getPro();

        ?>

        </div><!-- row Ends -->

    </section>

</div>