<?php 

include('../../function/database.php');
include('header.php');

  $get_ip = getRealUserIp();

  $select = "select email from mb where ip_add='$get_ip'";

  $run_cart = mysqli_query($con,$select);

 /*if (mysqli_num_rows($run_cart)){
    while($row = mysqli_fecth_assoc($run_cart)){

        $email = $row['email'];

        $_SESSION['email'] = $email;

        glob $_SESSION['email'];

    }

  }else{
    echo "<script>alert('please login to access this page if you dont have an account login')</script>";
    echo "<script>window.open('../../index.php', '_self')</script>";
  }*/


?>
<body >



<div class="Wrapper">
		<div class="Nav-bar" style="top: 0; "><?php include('navbar.php'); ?></div>
		<div class="Links"><?php include('links.php'); ?></div>
		<div class="ads" > <?php include('ads.php'); ?></div>
    <div class="Body" style="display: inline"><?php include('bodydocuments.php');?></div>
		<div class="footer"><?php include('footer.php');?> </div>

</div>





<script>
  $(document).ready(function(){
      $(window).resize();
  });
  $(window).resize(function{
      // your code
      var windowWidth=$(window).width();
      var mainContainerWidth=windowWidth-100; // For example
      $("#yourMainContainer").css({"width":mainContainerWidth+"px"});
  });
</script>

    <script type='text/javascript' src='http://ajax.googleapis.com/ajax/libs/jquery/1.4/jquery.min.js'></script>
 
</body>
</html>