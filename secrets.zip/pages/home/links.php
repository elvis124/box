<div class="box1" id='page-wrap'>
	<ul style="list-style-type: none; padding-top: 30px; justify-content: center;">
		<li ><a href="documents.php" style="background-color: transparent; color: white">Documents</a></li>
		<li style="padding-top: 10px;"><a href="audio.php" style="background-color: transparent; color: white">Audio</a></li>
		<li style="padding-top: 10px;"><a href="videos.php" style="background-color: transparent; color: white">Videos</a></li>
		<li style="padding-top: 10px;"><a href="photos.php" style="background-color: transparent; color: white">photos</a></li>
		<li style="padding-top: 10px;"><a href="money.php" style="background-color: transparent; color: white">Money</a></li>
		<li style="padding-top: 10px;"><a href="minerals.php" style="background-color: transparent; color: white">Minerals</a></li>


		<p style="color: orange; padding-top:  30px;"><b>your privacy  is our main concern.


			</b><i>we offer you infinite  security to your products  </i></p>


	    <p style="color: orange; padding-top:  30px;">This plartform is so private that only you can access this page</p>

	    <marquee style="padding-top: 30px; color: yellow">your privacy is our main concern</marquee>

	</ul>


</div>