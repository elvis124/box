 <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->
<div class="box5">
  <nav class="navbar navbar-icon-top navbar-expand-lg navbar-dark bg-dark" style="justify-content: space-between; background-color: transparent; ! important;">

    
    <h1><a class="navbar-brand" href="#" style="color: orange">Mx box</a><img src="../../images/mx.png" style="width: 70px;"></h1>

    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>



    <div class="collapse navbar-collapse" id="navbarSupportedContent" style="justify-content: center">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item active">
          <a class="nav-link" href="#">
            <i class="fa fa-home"></i>
                 Home
            <span class="sr-only">(current)</span>
            </a>



        </li>
        <li class="nav-item active" style="padding-left: 90px;">
         <?php           
          if(isset($_SESSION['email'])){
          echo '<a class="nav-link" href="#">
                 $_SESSION["email"];
            <span class="sr-only">(current)</span>
            </a>';

          }?>
        </li>




         <form class="form-inline my-2 my-lg-0" style="padding-left: 140px; background-color: (0,0,0,.6);">
           <input class="form-control mr-sm-2" type="text" placeholder="Search" aria-label="Search">
           <button class="btn btn-outline-success my-2 my-sm-0"  style="color: brown"; type="submit">Search</button>
         </form>
    
  
      <ul class="navbar-nav " style="padding-left: 90px;">
        <li class="nav-item" style="padding-right: 30px;">
          <a class="nav-link dropdown-toggle"  href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-user-cog"></i>
              Accouunt settings
          </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown" >
            <a class="dropdown-item" href="#">update profile</a>
            <a class="dropdown-item" href="#">change password</a>
            <a class="dropdown-item" href="#">next of kin</a>


          </div>
        </li>
        <li class="nav-item" style="padding-left: 90px">
          <a class="nav-link" href="logout.php" style="color: blue">
          <i class="fa fa-sign-out" aria-hidden="true"></i>

            [**signout**-->]
          </a>
        </li>
      </ul>

    </div>
  </nav>
</div>

