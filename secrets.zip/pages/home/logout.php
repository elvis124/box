<?php 
  

   echo "<script style='xslt_backend_info('signing out')'>alert('thank you for trusting us your privacy is our main concern')</script>";
   echo "<script>window.open('../../index.php', '_self');</script>"



?>