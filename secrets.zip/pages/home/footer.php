<link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<footer class="footer-section bg-with-black" style="background-color: grey;">
        <div class="footer-top-section">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="single-fta">
                            <img src="http://themeinnovation.com/demo2/html/build-up/img/home1/logo2.png" alt="">
                            <ul class="fta-list">
                                <li><a href="kin.php">Next of kin </a></li>
                                <li><a href="planning.php">financial planning </a></li>
                                <li><a href="product.php">product management</a></li>
                                <li><a href="management.php">subscription management</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="single-fta">
                            <h3 class="fta-title">About us</h3>
                            <ul class="fta-list">
                                <li>Address: kisumu, Riat</li>
                                <li>Phone: (+254)703180147</li>
                                <li>Email: elvisianomondi@gmail.com</li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="single-fta" style="padding-right: 50px;">
                     <div class="mapouter"><div class="gmap_canvas"><iframe width="279" height="189" id="gmap_canvas" src="https://maps.google.com/maps?q=2880%20Broadway,%20New%20York&t=&z=13&ie=UTF8&iwloc=&output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe><a href="https://www.whatismyip-address.com/divi-discount/"></a><br><style>.mapouter{position:relative;text-align:right;height:189px;width:279px;}</style><a href="https://www.embedgooglemap.net">embedgooglemap.net</a><style>.gmap_canvas {overflow:hidden;background:none!important;height:189px;width:279px;}</style></div></div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="single-fta">
                            <h3 class="fta-title">Contact Us</h3>
                            <ul class="fta-list">
                                <form method="POST" action="../../function/contact.php">
                                    <div class="form-group">
                                        <li><input type="text" name="email" placeholder="email" style="outline: none; width: 100%" ></li>
                                    </div>
                                    <div class="form-group">
                                        <li><input type="text" name="subject" placeholder="subject" style="outline: none; width: 100%"></li>
                                    </div>
                                    <div class="form-group">
                                        <textarea name="message"  placeholder="enter message" style="outline: none; width: 100%;"></textarea>
                                    </div>
                                    <div class="form-group">
                                        <button name="submit" style="background-color: red; width: 100%; border-radius: 40px; color: white; outline: none;">send</button>
                                    </div>
                                </form>

                            </ul>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
        <div class="footer-bottom-area">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="footer-bottom">
                            <div class="row">
                                <div class="col-md-6 col-sm-12 col-xs-12">
                                    <div class="fba-copyright">
                                        <p>Copyright © 2020 Designed by mx box. All rights reserved.</p>
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-12 col-xs-12">
                                    <div class="fba-links">
                                        <ul>
                                            <li><a href="about.php">About</a></li>
                                            <li><a href="#">Contact Us</a></li>
                                            <li><a href="#">Term & Conditions</a></li>
                                            <li><a href="#">Privacy Policy</a></li>
                                            <li><a href="#">Sites Map</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>