s<?php 

include('includes/header.php');
?>
<body >
  <div class="container" style="padding-top: 20px; ">
    <div class="forms-container">
      <div class="signin-signup">
          <form action="pages/login.php" method="POST" class="sign-in-form" >
            <h2 class="title" style="color: white">Sign in</h2>

            <div class="input-field">
              <i class="fas fa-code"></i>
              <input type="text" name="code" placeholder="secret code" required />
            </div>
            <div class="input-field">
              <i class="fas fa-user"></i>
              <input type="text" name="email" placeholder="email" required />
            </div>
            <div class="input-field">
              <i class="fas fa-lock"></i>
              <input type="password" name="password" placeholder="Password" required />
            </div>
            <input type="submit" name="submit" style="color: yellow;" value="Login" class="btn solid" /></b>
            <p class="social-text" style="color: red">Sign in with social platforms</p>
            <div class="social-media" style="background-color: green;">
              <a href="#" class="social-icon" style="color: white">
                <i class="fab fa-facebook-f"></i>
              </a>
              <a href="#" class="social-icon" style="color: white">
                <i class="fab fa-twitter"></i>
              </a>
              <a href="#" class="social-icon" style="color: white">
                <i class="fab fa-google"></i>
              </a>
              <a href="#" class="social-icon" style="color: white">
                <i class="fab fa-linkedin-in"></i>
              </a>
            </div>
          </form>


          <form action="pages/register.php" method="POST" class="sign-up-form" enctype="multipart/form-data">
            <b><h1 style="color: white">Register</h1></b>
            <div class="input-field">
              <i class="fas fa-user"></i>
              <input type="text" name="username" placeholder="Username" required />
            </div>

            <div class="input-field">
              <i class="fas fa-phone"></i>
              <input type="number" name="number" placeholder="phone number +254" required />
            </div>

            <div class="input-field">
              <i class="fas fa-user"></i>
              <input type="text" name="full_names" placeholder="full names" required />
            </div>
             <input type="file" name="image"  placeholder="profile pic" style="color: white" required />
            <div class="input-field">
              <i class="fas fa-envelope"></i>
              <input type="email" name="email" placeholder="Email" required />
            </div>

            <div class="input-field">
              <i class="fas fa-lock"></i>
              <input type="password" name="password" id='pass' placeholder="Password" required />
            </div>

            <div class="input-field">
              <i class="fas fa-lock"></i>
              <input type="password"  name="confirm_password" id='con_pass' placeholder="confirm password" required="" />
            </div>


            <input type="submit" name="register" style="color: yellow;" class="btn" value="Sign up" />
            <p class="social-text" style="color: red">Sign up with social platforms</p>
            <div class="social-media" style="background-color: green">
              <a href="#" class="social-icon" style="color: white">
                <i class="fab fa-facebook-f" ></i>
              </a>
              <a href="#" class="social-icon" style="color: white">
                <i class="fab fa-twitter"></i>
              </a>
              <a href="#" class="social-icon" style="color: white">
                
                <i class="fab fa-google"></i>
              </a>
              <a href="#" class="social-icon" style="color: white">
                <i class="fab fa-linkedin-in"></i>
              </a>
            </div>
          </form>
        </div>
      </div>


      <div class="panels-container" style="background-color: transparent;">
        <div class="panel left-panel">
          <div class="content"  >
           <p><h1 style="background-color: rgba(120, 30, 30, 0.4);">mx box<img src='images/mx.png'></h1></p>
              <h2>welcome back to <b>mx box</b></h2>
              <p><i style="color: yellow">your secret privacy is our main concern </i></p>
              <p><h3>store your most valuable private files here at only $30 yearly use it for free during the first month</h3></p>
            <button class="btn transparent" id="sign-up-btn">
              Sign up
            </button>
          </div>
        </div>


        <div class="panel right-panel" >
          <div class="content">
            <p><h1 style="background-color: rgba(120, 30, 30, 0.4);">mx box<img src='images/mx.png'></h1></p>
            <h3>Hello  freind , how is your day? welcome to [ mx box ]</h3>
            <p><h3>store your most valuable secretive files with us at only $30 yearly use it for free during the first month</h3></p>
            <p><i style="color: yellow; ">your secret privacy is our mian concern</i></p>
            <button class="btn transparent" id="sign-in-btn">
              Sign in
            </button>
          </div>
        </div>
      </div>
    </div>


<script>

$(document).ready(function(){
$('.confirm').focusout(function(){

var password = $('#pass').val();

var confirmPassword = $('#con_pass').val();

if(!password== confirmPassword){
  window.alert("your passwords do not match");
}



</script>

<script>
  $(document).ready(function(){
      $(window).resize();
  });
  $(window).resize(function{
      // your code
      var windowWidth=$(window).width();
      var mainContainerWidth=windowWidth-100; // For example
      $("#yourMainContainer").css({"width":mainContainerWidth+"px"});
  });
</script>
<script src="styles/main.js"></script>
</body>
</html>
